﻿using System;
using System.Threading;
using ServiceStack;
using System.Collections.Generic;

namespace IEMemoryLeak
{
    public class StuffToSend
    {
        public string attrib1;
        public string attrib2;
        public string attrib3;
        public IList<StuffToSend> childs;
    }
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            new AppHost().Init();
            Thread thread = new Thread(new ThreadStart(BombardmentAway));
            thread.Start();
        }

        public void BombardmentAway()
        {
            var serverEvents = AppHostBase.Instance.Container.TryResolve<ServiceStack.IServerEvents>();
            StuffToSend stuff = new StuffToSend();
            stuff.childs = new List<StuffToSend>(20);
            stuff.attrib1 = "jielrjailerjilaerjilae jil jalikerj934j3ljailerjil4jli3jladsjfkladjfliajrlkiaerjliaerjliearjileajrilaejrliaejrliaejrliaejrilaejrilaejrliaejrlaiejr";
            stuff.attrib2 = "jielrjailerjilaerjilae jil jalikerj934j3ljailerjil4jli3jladsjfkladjfliajrlkiaerjliaerjliearjileajrilaejrliaejrliaejrliaejrilaejrilaejrliaejrlaiejr";
            stuff.attrib3 = "jielrjailerjilaerjilae jil jalikerj934j3ljailerjil4jli3jladsjfkladjfliajrlkiaerjliaerjliearjileajrilaejrliaejrliaejrliaejrilaejrilaejrliaejrlaiejr";
            for (int i=0; i< 500; i++)
            {
                stuff.childs.Add(new StuffToSend() {attrib1="huekrhukaehrukehukahrukehakurheukahrkuaehrkuaerhkuaerhakuerhkuaehrkauehrkauehrkaeurhkauehrkauehrkauehrkauehrkauehruakehrkuaehrakuehrkuaehrkauehrukeahrkuaherukaehreukahruakehrkuaehrukaerhkauerhkauehrkauehrkauerhkauhrkuaehrkauehrkauehrkauehrkauehrkauehrkauehrkauehraer" ,
                attrib2= "huekrhukaehrukehukahrukehakurheukahrkuaehrkuaerhkuaerhakuerhkuaehrkauehrkauehrkaeurhkauehrkauehrkauehrkauehrkauehruakehrkuaehrakuehrkuaehrkauehrukeahrkuaherukaehreukahruakehrkuaehrukaerhkauerhkauehrkauehrkauerhkauhrkuaehrkauehrkauehrkauehrkauehrkauehrkauehrkauehraer",
                attrib3= "huekrhukaehrukehukahrukehakurheukahrkuaehrkuaerhkuaerhakuerhkuaehrkauehrkauehrkaeurhkauehrkauehrkauehrkauehrkauehruakehrkuaehrakuehrkuaehrkauehrukeahrkuaherukaehreukahruakehrkuaehrukaerhkauerhkauehrkauehrkauerhkauhrkuaehrkauehrkauehrkauehrkauehrkauehrkauehrkauehraer"
                });
            }
            while (true)
            {
                //System.Diagnostics.Debugger.Launch();
                Thread.Sleep(25);
                serverEvents.NotifyAll("cmd.bombard", stuff);
            }

        }
    }
}

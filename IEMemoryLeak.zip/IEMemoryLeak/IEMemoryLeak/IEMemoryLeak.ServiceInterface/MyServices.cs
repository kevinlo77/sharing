﻿using ServiceStack;
using IEMemoryLeak.ServiceModel;

namespace IEMemoryLeak.ServiceInterface
{
    public class MyServices : Service
    {
        public object Any(Hello request)
        {
            return new HelloResponse { Result = $"Hello, {request.Name}!" };
        }
    }
}
﻿var activeSubsciption = null;

var es = new EventSource("/IEMemoryLeak/event-stream");
$(es).handleServerEvents({
    handlers: {
        onConnect: function (subscription) {
            if (isSubscribed() && appStateService.isInWorklistContext()) {
                console.debug("onConnect: set subscription");
            }
            if ((isSubscribed()) && (activeSubsciption.id !== subscription.id)) {
                if (true) {
                    console.debug("onConnect: found previous active subscription; unregistering old subscription");
                }
                $http.post(activeSubsciption.unRegisterUrl);
            }
            activeSubsciption = subscription;
        },
        bombard: function (message, e) {
            if (isSubscribed() && true) {
                console.info("Push update for selected cases occurred");
                {
                    console.debug(message);
                }
            }
        },
        stopListening: function () {
            $.ss.eventSource.close();
        }
    },
    success: function (selector, msg, json) {
        lastErrorTimestamp = null; // reset 'timeout' for errors
        if (isSubscribed()) {
            console.log(selector + json + msg)
        }
    }
});

function isSubscribed() {
    return (activeSubsciption != null);
}